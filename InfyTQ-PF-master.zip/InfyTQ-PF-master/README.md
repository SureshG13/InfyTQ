# InfyTQ-Programming Fundamentals using Python course' exercises and assignments
