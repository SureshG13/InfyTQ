//PF-Exer-13
num1=5
num2=6
sum=0
//Write your code here
if(num1==num2){
    sum=num1+num2
}
else{
    sum=(num1+num2)*2
}
console.log(sum)
