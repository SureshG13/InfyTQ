//PF-Exer-24
//This verification is based on string match.

package main

import ("fmt")
func find_square(n int)(int){
    return n*n
}
func main() {
    var n int=3
    fmt.Println(find_square(n))
}
